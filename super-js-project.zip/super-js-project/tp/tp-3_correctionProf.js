console.log('------TP 3-------');
import DOMPurify from 'dompurify';
let attack1 = '<script>alert("XSS Attack!");</script>';
console.log('avant DOM Purify',attack1);
console.log('apreès DOM Purify',DOMPurify.sanitize(attack1));

// userInput.value = '<script>alert("XSS Attack!");</script>';
// userInput.value = `<button onclick="alert('Attaque XSS!');">XSS Button</button>`;
let selectedForm = false;
// Forms UI Elements
const formCOnnexionUI = document.querySelector('#connexionForm');
const formInscriptionUI = document.querySelector('#inscriptionForm');
const formTitleUI = document.querySelector('#formTitle');

const checkBoxLabelUI = document.querySelector('#checkboxLabel');
const infoBoxUI = document.querySelector('#securityInfo');

// Inputs Email
const connexionInputEmailUI = document.querySelector('#connexionInputEmail');
const inscriptionEmailUI = document.querySelector('#inscriptionInputEmail');
const allEmailInputsUI = document.querySelectorAll('.emailInput');

// Inputs Password
const connexionInputPasswordUI = document.querySelector('#connexionInputPassword');
const allPasswordInputsUI = document.querySelectorAll('.passwordInput');
const inscriptionPassWordsCheckUI = document.querySelectorAll('.pwdCheck');

const regexObj = {
    regexMail : /^[a-z0-9._-]+@[a-z0-9._-]+\.[a-z]{2,6}$/,
    charDecimal : /\d/,
    charSpecial : /[$&@!]/,
    xssPattern:/<script.*?>.*?<\/script>|<.*?onclick=.*?>|<.*?on\w+=".*?"/i
};
let errorMsg = {
    mailMsg:'',
    passwordMsg:'',
    xssMsg:''
};

formCOnnexionUI.addEventListener('submit',(e)=>{
    e.preventDefault();
})
formInscriptionUI.addEventListener('submit',(e)=>{
    e.preventDefault();
})

displayForm(selectedForm);

function xssInputChecker(inputParam) {
    if (regexObj.xssPattern.test(inputParam.value)) {
        infoBoxUI.style.display='block';
        errorMsg.xssMsg = `<p>⛔️ Attention : potentiel XSS détecté.</p>`;
    } else {
        errorMsg.xssMsg = ''; // Réinitialiser le message
    }
};

function passwordMatchChecker(inputParamColl) {
    if (inputParamColl[0].value !== inputParamColl[1].value) {
        errorMsg.passwordMsg += `<p>⛔️ ≠ Les mots de passe ne correspondent pas.</p>`;
    } else {
        errorMsg.passwordMsg += `<p>✅ Les mots de passe correspondent.</p>`;
    }
    displayErrorMessages(); // Appel à la fonction pour afficher les messages d'erreur
};

function emailInputChecker(paramInput) {
    if (regexObj.regexMail.test(paramInput.value)) {
        paramInput.style.backgroundColor='lightgreen';
        errorMsg.mailMsg = `<p>✅ Le format du mail est correct.</p>`;
    } else {
        infoBoxUI.style.display='block'
        paramInput.style.backgroundColor='red';
        errorMsg.mailMsg = `<p>⛔️ Le format du mail n'est pas correct.</p>`;
    }
    displayErrorMessages(); // Appel à la fonction pour afficher les messages d'erreur
};
allEmailInputsUI.forEach(element => {
    element.addEventListener('keyup',()=>{
        xssInputChecker(element);
        emailInputChecker(element);
    });
});
allPasswordInputsUI.forEach(element => {
    element.addEventListener('keyup',()=>{
        passwordInputChecker(element);
        xssInputChecker(element);
    });
});
inscriptionPassWordsCheckUI.forEach(element => {
    element.addEventListener('keyup', () => {
        // On passe direct la collection
        passwordMatchChecker(inscriptionPassWordsCheckUI);
    });
});

function passwordInputChecker(inputParam) {
    errorMsg.passwordMsg = ''; // Réinitialiser le message

    if (inputParam.value.length < 6) {
        errorMsg.passwordMsg += `<p>⛔️ Mot de passe trop Faible</p>`;
    } 
    if (inputParam.value.length > 12) {
        errorMsg.passwordMsg += `<p>⛔️ Mot de passe trop Long</p>`;
    } 
    if (!inputParam.value.match(regexObj.charDecimal)) {
        errorMsg.passwordMsg += `<p>⛔️ Le Mot de passe doit contenir un chiffre</p>`;
    }
    if (!inputParam.value.match(regexObj.charSpecial)) {
        errorMsg.passwordMsg += `<p>⛔️ Le Mot de passe doit contenir un caractère spécial</p>`;
    }
    if(!errorMsg.passwordMsg){
        errorMsg.passwordMsg = `<p>✅ Le mot de passe est correct</p>`
    }
    displayErrorMessages(); // Appel à la fonction pour afficher les messages d'erreur
};

// Nouvelle fonction pour afficher les messages d'erreur cumulés
function displayErrorMessages() {
    let combinedMsg = '';
    if (errorMsg.mailMsg) combinedMsg += errorMsg.mailMsg;
    if (errorMsg.passwordMsg) combinedMsg += errorMsg.passwordMsg;
    if (errorMsg.xssMsg) combinedMsg += errorMsg.xssMsg; // Ajout de la gestion du message XSS
    infoBoxUI.innerHTML = combinedMsg;
    infoBoxUI.style.display = combinedMsg ? 'block' : 'none'; // Affiche ou cache la boîte d'information
};

//*-------------------   UI CHECKBOX  -----------------
const checkBoxFormUI = document.querySelector('#flexSwitchCheckDefault');

checkBoxFormUI.addEventListener('click', () => {
    selectedForm = !selectedForm;
    displayForm(selectedForm);
});
function displayForm(boolParam) {
    // infoBoxUI.style.display='none';
    formCOnnexionUI.reset(); // Réinitialiser les valeurs des inputs du formulaire de connexion
    formInscriptionUI.reset(); // Réinitialiser les valeurs des inputs du formulaire d'inscription
    infoBoxUI.innerHTML='';
    // Réinitialiser le fond des inputs
    allEmailInputsUI.forEach(input => {
        input.style.backgroundColor = ''; // Réinitialiser la couleur de fond
    });
    connexionInputPasswordUI.style.backgroundColor = ''; // Réinitialiser la couleur de fond du mot de passe
    formCOnnexionUI.style.display = boolParam ? 'none' : 'block';
    formInscriptionUI.style.display = boolParam ? 'block' : 'none';
    formTitleUI.innerText = boolParam ? `Formulaire d'Inscription` : 'Formulaire de Connexion';
    checkBoxLabelUI.innerText = boolParam ? `Vous avez déjà un compte ?` : 'Pas encore Inscrit ?';
};