//* Bouton
const boutonChange = document.querySelector('#flexSwitchCheckDefault');
console.log(boutonChange);
const formConnexion = document.querySelector('#connexionForm');
console.log(formConnexion);
const formInscription = document.querySelector('#inscriptionForm');
console.log(formInscription);
const messageBtn = document.querySelector('#checkboxLabel');
messageBtn.innerText = 'Vous avez déja un compte?'
boutonChange.addEventListener('click', () => {
    formInscription.classList.toggle('hidden' );
    formConnexion.classList.toggle('hidden');
    messageBtn.innerText = `Vous n'avez pas un compte?`;
})


/*
Faire une boleean avec variable = !variable. variable=true et chaque fois que on click c'est faux. et apres function display form. si 
//*-------------------   UI CHECKBOX  -----------------
const checkBoxFormUI = document.querySelector('#flexSwitchCheckDefault');

checkBoxFormUI.addEventListener('click', () => {
    selectedForm = !selectedForm;
    displayForm(selectedForm);
});
function displayForm(boolParam) {
    // infoBoxUI.style.display='none';
    formCOnnexionUI.reset(); // Réinitialiser les valeurs des inputs du formulaire de connexion
    formInscriptionUI.reset(); // Réinitialiser les valeurs des inputs du formulaire d'inscription
    infoBoxUI.innerHTML='';
    // Réinitialiser le fond des inputs
    allEmailInputsUI.forEach(input => {
        input.style.backgroundColor = ''; // Réinitialiser la couleur de fond
    });
    connexionInputPasswordUI.style.backgroundColor = ''; // Réinitialiser la couleur de fond du mot de passe
    formCOnnexionUI.style.display = boolParam ? 'none' : 'block';
    formInscriptionUI.style.display = boolParam ? 'block' : 'none';
    formTitleUI.innerText = boolParam ? `Formulaire d'Inscription` : 'Formulaire de Connexion';
    checkBoxLabelUI.innerText = boolParam ? `Vous avez déjà un compte ?` : 'Pas encore Inscrit ?';
};
*/


//*Regex e-mail
const emailConnexionInput = document.querySelector('#connexionInputEmail');
console.log(emailConnexionInput);
const divMessage = document.querySelector("#securityInfo")
console.log(divMessage);
const securityMessage= document.createElement('ul');
divMessage.append(securityMessage);
console.log(securityMessage);
divMessage.style.display = "block";
const regexEmail = /^[a-z0-9._-]+@[a-z0-9._-]+\.[a-z]{2,6}$/;
const xssPattern =  /<script.*?>.*?<\/script>|<.*?onclick=.*?>|<.*?on\w+=".*?"/i;
emailConnexionInput.addEventListener('keyup',() => {
    if(regexEmail.test(emailConnexionInput.value) === true){
        emailConnexionInput.style.backgroundColor = "green"
        securityMessage.innerHTML = `<li>✔️ Le format du email c'est correct </li>`
    }else{
        emailConnexionInput.style.backgroundColor = 'red';
        securityMessage.innerHTML = `<li>❌ Le format du email c'est incorrect </li>`;
        xssPattern.test(emailConnexionInput) === true ? securityMessage.innerHTML += `<li>❌ Attention: potentiel XSS détecté </li>` : securityMessage.innerHTML ='';
        }
        console.log(regexEmail.test(emailConnexionInput));
    }
)

//* regex email Inscription
const emailInscriptionInput = document.querySelector('#inscriptionInputEmail');
console.log(emailConnexionInput);
divMessage.style.display = "block";
emailInscriptionInput.addEventListener('keyup',() => {
    if(regexEmail.test(emailInscriptionInput.value) === true){
        emailInscriptionInput.style.backgroundColor = "green";
        securityMessage.innerHTML = `<li>✔️ Le format du email c'est correct </li>`;
    }else{
        emailInscriptionInput.style.backgroundColor = 'red';
        securityMessage.innerHTML = `<li>❌ Le format du email c'est incorrect </li>`;
        emailInscriptionInput.value.match(xssPattern) === null ? securityMessage.innerHTML += `<li>❌ Attention: potentiel XSS détecté </li>` : securityMessage.innerHTML ='';
        }
        console.log(regexEmail.test(emailInscriptionInput));
    }
)


//* Regex Mot de passe conexion
const passwordConnexion = document.querySelector('#connexionInputPassword');
console.log(passwordConnexion);
const regexPassword = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z][$&@!]).{8,}$/gm;
let errorMessage = ``;
passwordConnexion.addEventListener('blur', () => {
    if (passwordConnexion.value.match(regexPassword) != null){
        passwordConnexion.style.backgroundColor = 'green';
        securityMessage.innerHTML = `<li>✔️ Mot de passe correct!</li> `;
    }else {
        passwordConnexion.style.backgroundColor = "red"; 
            errorMessage += `<li>❌ Mot de passe faible! </li>`;
        passwordConnexion.value.length < 8 ?
            errorMessage += `<li>❌ Mot de passe trop court</li>` : errorMessage += ``;
        passwordConnexion.value.match(/\d/) === null ? 
            errorMessage += `<li>❌ Le mot de passe doit contenir un chiffre</li>` : errorMessage += ``;
        passwordConnexion.value.match(/[$&@!]/) === null ?
            errorMessage += `<li>❌ Le mot de passe doit contenir un caractére spécial</li>` : errorMessage += ``;
            securityMessage.innerHTML = errorMessage;
        } 


})

//* regex mot de passe inscription
const passwordInscription = document.querySelector('#inscriptionInputPassword');
console.log(passwordInscription);
let errorMessageInscription = '';
passwordInscription.addEventListener('blur', () => {
    if (passwordInscription.value.match(regexPassword) != null){
        passwordInscription.style.backgroundColor = 'green';
        securityMessage.innerHTML = `<li>✔️ Mot de passe correct!</li> `;
    }else {
        passwordInscription.style.backgroundColor = "red"; 
            errorMessageInscription += `<li>❌ Mot de passe faible! </li>`;
        passwordInscription.value.length < 8 ?
            errorMessageInscription += `<li>❌ Mot de passe trop court</li>` : errorMessageInscription += '';
        passwordInscription.value.match(/\d/) == null ? 
            errorMessageInscription += `<li>❌ Le mot de passe doit contenir un chiffre</li>` : errorMessageInscription += '';
        passwordInscription.value.match(/[$&@!]/) == null ?
            errorMessageInscription += `<li>❌ Le mot de passe doit contenir un caractére spécial</li>` : errorMessageInscription += '';
        securityMessage.innerHTML = errorMessageInscription;
    } 
})

//* regex mot de passe confirm
const passwordConfirm = document.querySelector('#inscriptionInputConfirmPassword');
console.log(passwordConfirm);
passwordConfirm.addEventListener('blur', () => {
    if(passwordConfirm.value === ''){
        securityMessage.innerHTML = '';
    }
    else if (passwordConfirm.value == passwordInscription.value){
        securityMessage.innerHTML = `<li>✔️ Les mots de passe correspondent!</li> `;
    } else{
        securityMessage.innerHTML  = `<li>❌ Les mots de passe ne correspondent pas!</li> `;
    }
   })


