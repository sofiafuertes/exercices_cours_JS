//* Creation new Div
let info = document.createElement('div');
//* Style div Info
info.style.height = "300px";
info.style.width = "200px";
info.style.margin = "16px 0";
info.style.border = "3px solid grey"
info.style.padding = "16px 12px 24px 12px";
//* Selection div CardMeteo et bouton et inserer div Info avant le bouton
const divMeteo = document.querySelector('.cardMeteo');
console.log(divMeteo);
divMeteo.style.fontFamily = 'Verdana';
const btn = document.querySelector('button')
console.log(btn);
divMeteo.insertBefore(info,btn);

//* Creation function addInfo pour ajouter du text a div Info
function addInfo(text){
    info.innerHTML = text;
}

//* Creation function bouton pour ajouter un attribute a le bouton
function bouton(){
    btn.setAttribute('class','button__cardMeteo');
}

//* Event bouton orange
btn.addEventListener('mousedown', event =>{
    btn.style.backgroundColor = 'orange';
})
//* Event Bouton bleu
btn.addEventListener('mouseup', event =>{
    btn.style.backgroundColor = '' ;
})

//* Event click le bouton et conexion avec l'API et affichage info
btn.addEventListener('click', event =>{
 const infoApi = () => {
    fetch('https://prevision-meteo.ch/services/json/toulouse')
    .then(reponse => reponse.json())
    .then(data => {console.log(data)
                    addInfo(` 
                    Aujourd'hui le temps est: 
                    ${data.current_condition.condition} 
                    et la témperature est de 
                    ${data.current_condition.tmp}°C
                    T° Max = ${data.fcst_day_0.tmax} -
                    T° Min = ${data.fcst_day_0.tmin}`)
                console.log(info.innerHTML)})
    .catch(error => console.warn('Error' + error + error.stack));
 }
 infoApi();
 bouton();
})
